<?php return [
    'plugin' => [
        'name' => 'Plugin name',
        'description' => 'Plugin description.',
    ],
    'book' => [
        'title' => 'Title',
        'slug' => 'Slug',
        'author' => 'Author',
        'year' => 'Year',
        'short_description' => 'Short Description',
        'manage_book' => 'Manage Book',
        'manager_book' => 'Manage Book',
    ],
];